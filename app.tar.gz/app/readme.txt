  ____       _          ____ _                 _ 
 |  _ \ _ __(_) ___    / ___| | ___  _   _  __| |
 | |_) | '__| |/ _ \  | |   | |/ _ \| | | |/ _` |
 |  __/| |  | | (_) | | |___| | (_) | |_| | (_| |
 |_|   |_|  |_|\___/   \____|_|\___/ \__,_|\__,_|
------------------------------------------------------------------------ 


PrioCloud Todo list

+ redraw after calculation
+ user user login
+ paging: org dia, prio
+ rest storage data
- add new items
- organisation diagram
- org dia click load prio KPI
- dynamic KPI's



company
organisation department
KPI's
Projects