var SITE="";
var SITENAME="Prio";
var DBSERVER="http://priocloud.com:8080/rest";
var USERSERVER="http://priocloud.com:8080/user";
var PRIVATECLOUD="true";