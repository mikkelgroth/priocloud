angular.module('riskApp.controllers')
.controller('projectListCtrl', ['$scope','$rootScope', '$filter', 'restService', 'stateService', '$routeParams', function ($scope, $rootScope, $filter, restService, stateService, $routeParams) {
    var dashy;
    var obj = null;
	console.log($routeParams);
	console.log($routeParams.department_id);
	$scope.department=$routeParams.department_id;

	
	$scope.saveProjects = function() {
		console.log('updating all projects');
        angular.forEach($scope.projects, function(proj) {
        	restService.updateData('project',angular.fromJson(proj)).success(function(dataResponse) {
        		console.log("saved: " + proj);
                
        	});
        });
	}


    var redrawAll = function() {
        //popuplate dashboard
    	var cc={};
    	var labels={
	            "kpi1":$scope.company.projkpi1lable,
	            "kpi2":$scope.company.projkpi2lable,
	            "kpi3":$scope.company.projkpi3lable
    	}
    	$scope.freqData.labels=labels;
    	cc.projkpi1weight=($scope.company.projkpi1weight);
    	cc.projkpi2weight=($scope.company.projkpi2weight);
    	cc.projkpi3weight=($scope.company.projkpi3weight);
    	dashy = new Dashboard('#dashboard', $scope.freqData);

        //TODO fix this ugly copy hack so we only have one instance
        if($scope.company.projkpi1sort=="tophigh"){
            $scope.kpi1 = $filter('orderBy')(angular.copy($scope.freqData), '-freq.kpi1');
        }else{
            $scope.kpi1 = $filter('orderBy')(angular.copy($scope.freqData), 'freq.kpi1');
        }
        if($scope.company.projkpi2sort=="tophigh"){
            $scope.kpi2 = $filter('orderBy')(angular.copy($scope.freqData), '-freq.kpi2');
        }else{
            $scope.kpi2 = $filter('orderBy')(angular.copy($scope.freqData), 'freq.kpi2');
        }
        if($scope.company.projkpi3sort=="tophigh"){
            $scope.kpi3 = $filter('orderBy')(angular.copy($scope.freqData), '-freq.kpi3');
        }else{
            $scope.kpi3 = $filter('orderBy')(angular.copy($scope.freqData), 'freq.kpi3');
        }
 
};

    $rootScope.$watch('projects', function() {
		console.log("------------ projects changed");
		$scope.freqData=stateService.getProjects();
		$scope.company=stateService.getCompany();
		if($scope.projects && $scope.projects.length>0){
	        
			console.log($scope.projects.length);
	        recount($scope.kpi1, "kpi1", $scope.company.projkpi1sort);
	        recount($scope.kpi2, "kpi2", $scope.company.projkpi2sort);
	        recount($scope.kpi3, "kpi3", $scope.company.projkpi3sort);
            redrawAll();
		}
//		loadData();
	});

    $scope.$watch('company.projkpi1weight', function() {
        recount($scope.kpi1, "kpi1", $scope.company.projkpi1sort);
    });
    $scope.$watch('company.projkpi2weight', function() {
        recount($scope.kpi2, "kpi2", $scope.company.projkpi2sort);
    });
    $scope.$watch('company.projkpi3weight', function() {
        recount($scope.kpi3, "kpi3", $scope.company.projkpi3sort);
    });


    //load from database
    var loadData = function() {
        console.log('loading freqData list');
        restService.getData($scope.department).then(function(dataResponse) {
            if (dataResponse.data.length > 0) {
                $scope.freqData = dataResponse.data[0].freqData;
                obj = dataResponse.data[0];
            } else {
            	console.log('No data found - defaulting to initial data load');
                obj = null;
                $scope.freqData = initialData;
            }
            console.log($scope.freqData);
            console.log(initialData);
            redrawAll();
        });
    };

    function recount(arr, name, sort) {
    	if(!arr) return;
        
        var count = arr.length;
        if(sort=="tophigh"){
            angular.forEach(arr, function(item) {
                $scope.setValue(item.title, name, Math.round(100*count/arr.length));
                count--;
            });
           /* for(var i=arr.length-1 ; i>-1 ; i--){
                var item=arr[i];
                $scope.setValue(item.title, name, (i+1)*w);
            }
            */
        }else{
            count = 1;
            angular.forEach(arr, function(item) {
                $scope.setValue(item.title, name, Math.round(100*count/arr.length));
                count++;
            });
           /* for(var i=0;i<arr.length; i++){
                var item=arr[i];
                $scope.setValue(item.title, name, (i+1)*w);
            }
            */
        }
        if (dashy) {
        	dashy.redraw();
        }
    }
    
    $scope.kpi1Config = {
       stop: function(e, ui) {
           recount($scope.kpi1, "kpi1", $scope.company.projkpi1sort);
       }
    };

	$scope.kpi2Config = {
	    stop: function(e, ui) {
	        recount($scope.kpi2, "kpi2", $scope.company.projkpi2sort);
	    }
	};

	$scope.kpi3Config = {
	    stop: function(e, ui) {
	        recount($scope.kpi3, "kpi3", $scope.company.projkpi3sort);
	    }
	};

	/*
	$scope.$watch('user', function() {
	    if ($scope.user && $scope.user.authenticated) {
	        //setup rest and load todolist when user logs in
	        restService.setApplication($scope.user.auid, $rootScope.user.uuid);
	        loadData();
	    }
	});
*/
	
	$scope.addItem = function() {
	    var x = {
	        'title': 'Proj X',
	        freq: {
	            kpi1: 1,
	            kpi2: 1,
	            kpi3: 1
	        }
	    };
	    $scope.freqData.push(x);
	    //we need to redraw the entire dashboard due to more legends
	    redrawAll();
	}

	$scope.saveData = function() {
	    if (obj != null) {
	        obj.freqData = $scope.freqData;
	        restService.updateData(obj);
	    } else {
	        obj = {};
	        obj.freqData = $scope.freqData;
	        obj.department_id = $scope.department;
	        restService.saveData(obj).then(function(dataResponse) {
	        	obj=dataResponse.data;
        	});
	    }
	};

	$scope.deleteData = function() {
	    restService.deleteData(obj);
	};
	
  var initialData= [
            {'title': 'Proj A',freq:{kpi1:1, kpi2:1, kpi3:1}},
            {'title': 'Proj B',freq:{kpi1:2, kpi2:2, kpi3:2}},
            {'title': 'Proj C',freq:{kpi1:3, kpi2:3, kpi3:3}},
            {'title': 'Proj D',freq:{kpi1:4, kpi2:4, kpi3:4}},
            {'title': 'Proj E',freq:{kpi1:5, kpi2:5, kpi3:5}},
            {'title': 'Proj F',freq:{kpi1:6, kpi2:6, kpi3:6}},
            {'title': 'Proj G',freq:{kpi1:7, kpi2:7, kpi3:7}},
            {'title': 'Proj H',freq:{kpi1:8, kpi2:8, kpi3:8}},
            {'title': 'Proj I',freq:{kpi1:9, kpi2:9, kpi3:9}},
            {'title': 'Proj J',freq:{kpi1:10, kpi2:10, kpi3:10}},
            {'title': 'Proj K',freq:{kpi1:11, kpi2:11, kpi3:11}},
            {'title': 'Proj L',freq:{kpi1:12, kpi2:12, kpi3:12}}
  ];
    
      var baseConfig = {
          placeholder: "beingDragged",
          tolerance: 'pointer',
          items: 'li',
          revert: 100
      };

      //TODO use baseconfig to setup generic watch collection instead of the 3 hardcoded ones...
      $scope.priocloudConfig = angular.extend({}, baseConfig, {
          update: function(a,b,c){
              console.log('XXXXX');
              console.log(a);
              console.log(b);
              console.log(c);
              console.log('XXXXX');},    
      });

	 $scope.setValue = function(proj_name, type,val) {
		 /*
	     var found = $filter('filter')($scope.freqData, {title: proj_name}, true);
	     if (found.length) {
	         found[0].freq[type]=val;
	         recalculateScore();
	     }
	     */
        var w1 = +$scope.company.projkpi1weight;
        var w2 = +$scope.company.projkpi2weight;
        var w3 = +$scope.company.projkpi3weight;
        var wt = w1+w2+w3;
         
		 for(var i=0;i<$scope.freqData.length;i++){
			 if($scope.freqData[i].title==proj_name){
				 $scope.freqData[i].freq[type]=val;
                 $scope.freqData[i].total=Math.round(
                     (($scope.freqData[i].freq.kpi1*$scope.company.projkpi1weight)+
                     ($scope.freqData[i].freq.kpi2*$scope.company.projkpi2weight)+
                     ($scope.freqData[i].freq.kpi3*$scope.company.projkpi3weight))/wt);
			 }
		 }
	     console.log("UUUUUUUUUUUUU");

	 }
	 
/*	 //TODO: set UUID as ID from DB instead of this ugly search...
	 $scope.getByName = function(proj_name) {
	     var found = $filter('filter')($scope.freqData, {proj: proj_name}, true);
	     if (found.length) {
	         return (found[0]);
	     }
	     return null;
	 }
*/
    $scope.$watchCollection('freqData', function() {
       console.log('hey, myVar has changed!');
   });

/*    recalculateScore= function(){
       console.log('time to recalculate!');
        //let's recalculate the total
        angular.forEach($scope.freqData, function(item){
             item.total=item.freq.kpi1+item.freq.kpi2+item.freq.kpi3;
        });
    };
    */

}]);

