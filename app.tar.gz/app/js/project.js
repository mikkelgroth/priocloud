angular.module('riskApp.controllers')
.controller('ProjectCtrl', ['$scope','$rootScope', '$filter', 'restService', '$location', '$routeParams', 'stateService', function ($scope, $rootScope, $filter, restService, $location, $routeParams, stateService) {
	console.log("Project controller initialized");

	$scope.formatStupidDate = function(){
		debugger
		console.log("some one changed the date: ");
	}
	
    $scope.doStuff = function(poid){
    	$scope.directProject(poid);
    }
    
    $scope.barrender = function(mi){
    var s=new Date(Date.parse(mi.date));
    var e=new Date(Date.parse(mi.enddate));
    var start=0;
    var end=100;
    var thisyear=new Date();
    var base=new Date();
    base.setFullYear(thisyear.getFullYear(), 0, 1);
    var today = Math.round(((thisyear.getTime()-base.getTime())/86400000)*100/365);
    var oneday = today+1;
    if(today==100){ today=99; oneday=100;}
                
    if(thisyear.getFullYear()==s.getFullYear()) start=Math.round(((s.getTime()-base.getTime())/86400000)*100/365);
    if(thisyear.getFullYear()==e.getFullYear()) end=Math.round(((e.getTime()-base.getTime())/86400000)*100/365);        
    if(start==end && end!=100)end=end+1;
    if(start==100)start--;
    var color="grey";
        
    var ret = "#f6f1d3";
    if(start<end){
    if(today<=start){    
        ret = "linear-gradient(to right, #f6f1d3 "+today+"%, "+color+" "+today+"%, "+color+" "+oneday+"%, #f6f1d3 "+oneday+"%, #f6f1d3 "+start+"%, "+mi.status+" "+start+"%, "+mi.status+" "+end+"%, #f6f1d3 "+end+"%)";
    }
        
if(today>start && today<=end){    
        ret = "linear-gradient(to right, #f6f1d3 "+start+"%, "+mi.status+" "+start+"%, "+mi.status+" "+today+"%, "+color+" "+today+"%, "+color+" "+oneday+"%, "+mi.status+" "+oneday+"%,"+mi.status+" "+end+"%, #f6f1d3 "+end+"%)";
    }
        
if(today>end){ 
    if((mi.state=="Progress"||mi.state=="Target"||mi.state=="Qualified")) color="red";
        ret = "linear-gradient(to right, #f6f1d3 "+start+"%, "+mi.status+" "+start+"%, "+mi.status+" "+end+"%, #f6f1d3 "+end+"%, #f6f1d3 "+today+"%, "+color+" "+today+"%, "+color+" "+oneday+"%, #f6f1d3 "+oneday+"%)";

    }
        if(thisyear.getFullYear()>s.getFullYear() && thisyear.getFullYear()>e.getFullYear()){
            var dist = Math.round(today/2);
            if((mi.state=="Progress"||mi.state=="Target"||mi.state=="Qualified")) color="red";
            ret = "linear-gradient(to right, "+mi.status+" 0%, #f6f1d3 "+dist+"%, #f6f1d3 "+today+"%, "+color+" "+today+"%, "+color+" "+oneday+"%, #f6f1d3 "+oneday+"%)";
        }
        if(thisyear.getFullYear()<s.getFullYear() && thisyear.getFullYear()<e.getFullYear()){
            var dist = 100-Math.round((100-today)/2);
            ret = "linear-gradient(to right, #f6f1d3 "+today+"%, "+color+" "+today+"%, "+color+" "+oneday+"%, #f6f1d3 "+oneday+"%, #f6f1d3 "+dist+"%, "+mi.status+" 100%)";
        }
    
    }
        //debug consol
        if(ret==null)console.log(mi.title + " - " + ret + " Start: " + start + " End: " + end + " Today: " +today+ " Oneday: " +oneday+" color: "+color );
        
        //return
        return {background: ret}

    }

    
	 $scope.downloadPdf = function(domobj,title){
		 var pdf = new jsPDF('p','pt','a4');
		 pdf.addHTML(document.getElementById(domobj),function() {
			 pdf.save('Priocloud_'+title+'.pdf');
		 });
	 }   

    $scope.directProjectFromRisk = function(risk){
    	$scope.directProject(risk.projectoid);
        closeport();
    }

    $scope.directProjectFromMile = function(mile){
        $scope.directProject(mile.projectoid);
        closeport();
    }

    $scope.directProject=function (poid){
        angular.forEach(stateService.getProjects(), function(project) {
    		if(poid==project._id.$oid){
    			$scope.editProject(project);
    		}
    	});
        closeport();
    }
    
    $scope.directRiskLink = function(risk){
    	$scope.editRisk(risk);
    	showhide(5,5);
    	showhidepop(5,true);
        closeport();
    }

    $scope.directMilestoneLink = function(mile){
        $scope.editMile(mile);
    	showhide(4,5);
        showhidepop(4,true);
        closeport();
    }
    
	var xxx = 0;

	var tempabTotal = 0;
    var tempfteTotal = 0;
   
    $scope.setabTotal = function(s,n){
        tempabTotal+=n;
            s.abTotal=tempabTotal;
    }
    $scope.resetabTotal = function(){
        tempabTotal=0;
    }
    $scope.setfteTotal = function(s,n){
        tempfteTotal+=n;
            s.fteTotal=tempfteTotal;
    }

	$scope.xaxis = 'kpi1';
	$scope.yaxis = 'kpi2';
	$scope.size = 'EtC';
	
	$scope.$watch('xaxis', function() {
		$scope.drawScatter();
	});
	$scope.$watch('yaxis', function() {
		$scope.drawScatter();
	});
	$scope.$watch('size', function() {
		$scope.drawScatter();
	});
	
	//risk
	$scope.riskxaxis = 'kpi1';
	$scope.riskyaxis = 'kpi2';
	$scope.risksize = 'kpi3';
	
	$scope.$watch('riskxaxis', function() {
		$scope.drawRiskScatter();
	});
	$scope.$watch('riskyaxis', function() {
		$scope.drawRiskScatter();
	});
	$scope.$watch('risksize', function() {
		$scope.drawRiskScatter();
	});

	$scope.$watch('myfilter', function() {
		$scope.projects=stateService.getProjects();
		//Do filter here - remove unwanted projects
	});


	$rootScope.$watch('company', function() {
		console.log("------------ company changed");
		$scope.company=stateService.getCompany();
	});
	$rootScope.$watch('projects', function() {
		console.log("------------ projects changed");
		$scope.project=stateService.getProject();
		if($scope.project && $scope.project.freq){
			new minipie('#kpi1', $scope.project.freq.kpi1);
			new minipie('#kpi2', $scope.project.freq.kpi2);
			new minipie('#kpi3', $scope.project.freq.kpi3);
		    new minipie('#kpi4', $scope.project.total);
		}

		if($scope.project.statuses.length>0){
			$scope.editstatus=angular.copy($scope.project.statuses[$scope.project.statuses.length-1]);
			$scope.saveStatusEnabled=true;
		}
		$scope.projects=stateService.getProjects();
		console.log($scope.projects.length);
		$scope.drawScatter();
        
		//join all risks in one obj
		$scope.allrisks=[];
        angular.forEach(stateService.getProjects(), function(project) {
        	if(project.state!="Closed"){
                var risklist=[];
            angular.forEach(project.risks, function(risk) {
            	risk['projecttitle']=project.title;
            	risk['wtotal']=Math.round(project.total*risk.total/100); 
            	risk['projectstate']=project.state;
            	risk['projectoid']=project._id.$oid;
            	risk['buname']=project.bu.name;
            	risk['pkpi1']=project.freq.kpi1;
            	risk['pkpi2']=project.freq.kpi2;
            	risk['pkpi3']=project.freq.kpi3;
            	risk['ptotal']=project.total;
            	risk['ab']=project.statuses[project.statuses.length-1].ab;
            	risk['EtC']=project.statuses[project.statuses.length-1].EtC;
            	risk['fte']=project.statuses[project.statuses.length-1].fte;
            	risklist=risklist.concat(risk);
            });
        	$scope.allrisks=$scope.allrisks.concat(risklist);
            }
        });
        $scope.drawRiskScatter();
		
        //join all risks in one obj
		$scope.allMilestones=[];
        angular.forEach(stateService.getProjects(), function(project) {
            if(project.state!="Closed"){
        	var milestonelist=[];
            angular.forEach(project.milestones, function(milestone) {
            	milestone['projectoid']=project._id.$oid;
            	milestone['projecttitle']=project.title;
            	milestone['buname']=project.bu.name;
            	milestonelist=milestonelist.concat(milestone);
            });
        	       $scope.allMilestones=$scope.allMilestones.concat(milestonelist);
            }
        });
        
        //$scope.drawMilestones();

	});
	
    
    
    
//	if($scope.projects){console.log("got projects: " + $scope.projects.length)}else{console.log("No data found")}
//	console.log("EDIT> "+$scope.project);

	//ignore links if we are not logged in
	if (!($scope.user && $scope.user.authenticated)) {
		$rootScope.$watch('user', function() {
		    if ($scope.user && $scope.user.authenticated) {
		    	console.log("user changed");
		        //setup rest and load todolist when user logs in
//		        restService.setApplication($scope.user.auid, $rootScope.user.uuid);
//		        //loadCompany();
//				$scope.company=stateService.loadCompany();
//				$scope.users=stateService.loadUsers();
//		        $scope.projects=//stateService.loadProjects();
		        console.log($scope.projects);
		    }else{
				$location.path('/');
		    }
		});
	}
	//status
	$scope.newStatus = function() {
		console.log('newStatus');
		$scope.project.statuses.push({});
		$scope.editstatus={};
		$scope.saveStatusEnabled=true;
	}
	$scope.newCloneStatus = function() {
		console.log('newCloneStatus');
        $scope.editstatus.apo=""; 
        $scope.editstatus = angular.copy($scope.editstatus);
		$scope.project.statuses.push($scope.editstatus);
		$scope.saveStatusEnabled=true;
	}
	$scope.viewStatus = function(status) {
		console.log('VIEW STATUS');
		var last=$scope.project.statuses.indexOf(status)==$scope.project.statuses.length-1;
		$scope.saveStatusEnabled=last;
		$scope.editstatus=angular.copy(status);
	}
	
$scope.saveStatus = function() {
		console.log('SAVE STATUS');
		//TODO: change datepickr to be integrated with angular objects
		//date extractor bugfix thingy:
        var ed = new Date();
        if(ed instanceof Date && !isNaN(ed.valueOf())){$scope.editstatus.date=ed;}
        
		var ecd = new Date($("#closuredate")[0].value);
        if(ecd instanceof Date && !isNaN(ecd.valueOf())){$scope.editstatus.closuredate=ecd;}
        
		//end of date thing
    //set approved to blank if PM changes status
    if($scope.project.pm.email==$scope.user.email){
        $scope.editstatus.apo="";   
    }
		if($scope.project.statuses.length==0){
			$scope.project.statuses.push($scope.editstatus);
		}else{
			$scope.project.statuses[$scope.project.statuses.length-1]=$scope.editstatus;
		}
		saveProjectRedirect();		//save project without redirect
	}

	//milestone
	$scope.saveMilestones = function() {
        var md = new Date($("#miledate")[0].value);
        if(md instanceof Date && !isNaN(md.valueOf())){$scope.editmile.date=md.toISOString();}
        
		var med = new Date($("#mileenddate")[0].value);
        if(med instanceof Date && !isNaN(med.valueOf())){$scope.editmile.enddate=med.toISOString();}
        
		console.log('saveMilestones md ' +md+' editmile '+$scope.editmile.date);
		saveProjectRedirect();		//save project without redirect
	}
	$scope.newMilestone = function() {
		console.log('newMilestone');
		$scope.project.milestones.push({});
        $scope.editmile=$scope.project.milestones[$scope.project.milestones.length-1];
        
        
	}
	$scope.removeMilestone = function(milestone){
		$scope.project.milestones.splice($scope.project.milestones.indexOf(milestone), 1);
		saveProjectRedirect();		//save project without redirect
	}
	//risk
	$scope.newRisk = function() {
		$scope.editrisk={};
		$scope.editrisk.freq={};
		$scope.editrisk.freq.kpi1=$scope.project.risks.length;
		$scope.editrisk.freq.kpi2=$scope.project.risks.length;
		$scope.editrisk.freq.kpi3=$scope.project.risks.length;
	}
	$scope.removeRisk = function(risk){
		$scope.project.risks.splice($scope.project.risks.indexOf(risk), 1);
		saveProjectRedirect();		//save project without redirect
	}
	$scope.editRisk = function(risk){
		$scope.editrisk=risk;
        if($scope.editrisk && $scope.editrisk.freq){
			new minipie('#riskkpi1', $scope.editrisk.freq.kpi1);
			new minipie('#riskkpi2', $scope.editrisk.freq.kpi2);
			new minipie('#riskkpi3', $scope.editrisk.freq.kpi3);
		    new minipie('#riskkpi4', $scope.editrisk.total);
		}

	}
	$scope.editMile = function(mile){
		$scope.editmile=mile;
	}
	$scope.saveRisk = function(){
		console.log($scope.project);
		if(!$scope.editrisk.freq){
			$scope.editrisk.freq={};
			$scope.editrisk.freq.kpi1=$scope.project.risks.length;
			$scope.editrisk.freq.kpi2=$scope.project.risks.length;
			$scope.editrisk.freq.kpi3=$scope.project.risks.length;
		}
		if($scope.project.risks.indexOf($scope.editrisk)==-1){
			$scope.project.risks.push($scope.editrisk);	//new item
		}
		saveProjectRedirect();		//save project without redirect
		$scope.editrisk={};
	}
	//BU
	$scope.newBU = function() {
		console.log('add BU');
		$scope.bus.push({});
	}
	$scope.removeBU = function(bu){
		restService.deleteData('bu',angular.fromJson(bu)).success(function(dataResponse) {
			console.log('removed bu');
			$scope.bus.splice($scope.bus.indexOf(bu), 1);
		}).error(function(dataResponse) {console.log('ERROR ...');});
	}
	$scope.saveBus = function() {
		console.log('save BU');
		//console.log($scope.bus);
        angular.forEach($scope.bus, function(bu) {
    		//console.log(bu);
    		if(bu.ownerbu && bu._id == bu.ownerbu._id){
    			alert("Du kan ikke have en BU der peger på sig selv!!!");
    			return;
    		}
			if(bu._id){	//update
				restService.updateData('bu',angular.fromJson(bu)).success(function(dataResponse) {
					console.log('updated');
				}).error(function(dataResponse) {console.log('ERROR ...');});
			}else{	//add
				restService.saveData('bu',angular.fromJson(bu)).success(function(dataResponse) {
					$scope.bus[$scope.bus.indexOf(bu)]=dataResponse;	//update the oid via angular
					console.log('saved');
				}).error(function(dataResponse) {console.log('ERROR ...');});
			}
        });
	}
	//company
	$scope.saveCompany = function() {
		console.log('save Company');
		if($scope.company._id){	//update
			restService.updateData('company',angular.fromJson($scope.company)).success(function(dataResponse) {
				//stateService.loadCompany();
				//$location.path('/dashboard');
				alert('updated');
			}).error(function(dataResponse) {console.log('ERROR ...');});
		}else{	//add

/*			$scope.company.projkpi1lable= "Strategy";
				$scope.company.projkpi1sort= "tophigh";
				$scope.company.projkpi1weight= "5";
				$scope.company.projkpi2lable= "Revenue";
				$scope.company.projkpi2sort= "tophigh";
				$scope.company.projkpi2weight= "5";
				$scope.company.projkpi3lable= "Compliance";
				$scope.company.projkpi3sort= "tophigh";
				$scope.company.projkpi3weight= "6";
				$scope.company.riskkpi1lable= "Probability";
				$scope.company.riskkpi1sort= "tophigh";
				$scope.company.riskkpi1weight= "1";
				$scope.company.riskkpi2lable= "Delay";
				$scope.company.riskkpi2sort= "tophigh";
				$scope.company.riskkpi2weight= "1";
				$scope.company.riskkpi3lable= "Business loss";
				$scope.company.riskkpi3sort= "tophigh";
				$scope.company.riskkpi3weight= "1";
*/					
			restService.saveData('company',angular.fromJson($scope.company)).success(function(dataResponse) {
				$scope.company=dataResponse;	//update the oid via angular
				//add a BU with company name 
				var bu={name:$scope.company.name};
				restService.saveData('bu',angular.fromJson(bu)).success(function(dataResponse) {
					$scope.bus[0]=dataResponse;
				});
				//$location.path('/dashboard');
				alert('saved');
			}).error(function(dataResponse) {console.log('ERROR ...');});
		}
	}
	$scope.newProject = function(np) {
		$scope.project={};
        $scope.project.title=np.title;
        $scope.project.bu=np.bu;
        $scope.project.pm=np.pm;
        $scope.project.po=np.po;
        $scope.project.state='Proposed';
        $scope.project.freq={};
			$scope.project.freq.kpi1=1;
			$scope.project.freq.kpi2=1;
			$scope.project.freq.kpi3=1;
        $scope.project.total=1;
		
        $scope.project.statuses=[];
        $scope.project.statuses.push({});
		$scope.project.statuses[0].date=new Date();
        $scope.project.statuses[0].fte=np.fte;
        $scope.project.statuses[0].EtC=np.ab;
        $scope.project.statuses[0].ab=np.ab;
        $scope.project.statuses[0].status='Green';
        $scope.project.statuses[0].title='Project created';
        stateService.setProject($scope.project);
        saveProjectRedirect();
	}
	$scope.editProject = function(project) {
        closeport();
		stateService.setProject(project);
		$location.path('/project');
		//$scope.$apply();	//http://stackoverflow.com/questions/11784656/angularjs-location-not-changing-the-path
	}
	$scope.deleteProject = function(project) {
		restService.deleteData('project',angular.fromJson(project)).success(function(dataResponse) {
			var index=$scope.projects.indexOf(project);
		    $scope.projects.splice(index, 1);
			//stateService.loadProjects();
		    $scope.drawScatter();
		    $scope.drawRiskScatter();
		}).error(function(dataResponse) {console.log('ERROR DELETE PROJECT');});
	}
	$scope.saveProject = function() {
		console.log('SAVE PROJECT');
		saveProjectRedirect(); //no redirect
	}

	$scope.drawScatter = function() {
		console.log('DRAW SCATTER: ' + $scope.xaxis);
		//console.log($scope.projects);
		var data=[];
    	angular.forEach($scope.projects, function(p) {
    		//console.log(p);
    		//console.log(p.freq.kpi1);
            var laststatus=(p.statuses.length>1)?p.statuses[p.statuses.length-2].status:"green";
    		var proj={}
    		try{
	    		var proj={
                    "poid": p._id.$oid,
	    	        "title": p.title,
                    "state": p.state,
	    	        "Project": '<b>' + p.title + '</b><br/>State: ' + p.state +'<br/>BU: ' + p.bu.name +'<br/>PO: '+ p.po.name +'<br/>PM: '+ p.pm.name,
                    "total": p.total,
	    	        "EtC": p.statuses[p.statuses.length-1].EtC,
	    	        "ab": p.statuses[p.statuses.length-1].ab,
	    	        "fte": p.statuses[p.statuses.length-1].fte,
	    	        "kpi1": p.freq.kpi1,
	    	        "kpi2": p.freq.kpi2,
	    	        "kpi3": p.freq.kpi3,
	    	        "PM": p.pm,
	    	        "Status": p.statuses[p.statuses.length-1].status,
                    "Laststatus": laststatus
	    	    };
    		}catch(e){
	    		var proj={
	    	        "poid": p._id.$oid,
	    	        "title": p.title,
	    	        "state": "On hold",
	    	        "Project": p.title,
                    "total": 10,
	    	        "EtC": 10,
	    	        "ab": 10,
	    	        "fte": 1,
	    	        "Strategy": p.freq.kpi1,
	    	        "Complexity": p.freq.kpi2,
	    	        "Production": p.freq.kpi3,
	    	        "PM": p.pm,
	    	        "Status": 'Green',
	    	        "Laststatus": 'Green'
	    	    };
    		}
            if(proj.state!="Closed" && proj.state!="Onhold"){
    		  data.push(proj)
            }
    	});
		//var data=[{"Project":"P1","EtC":"10","Strategy":"7","Complexity":"4","Production":"1","Compliance":"6","PM":"MGA","Status":"Green"},{"Project":"P2","EtC":"20","Strategy":"4","Complexity":"5","Production":"8","Compliance":"1","PM":"MGA","Status":"Green"},{"Project":"P3","EtC":"12","Strategy":"1","Complexity":"6","Production":"7","Compliance":"8","PM":"MGA","Status":"Yellow"},{"Project":"P4","EtC":"5","Strategy":"2","Complexity":"1","Production":"6","Compliance":"2","PM":"MGA","Status":"Green"},{"Project":"P5","EtC":"7","Strategy":"3","Complexity":"2","Production":"2","Compliance":"7","PM":"MGA","Status":"Yellow"},{"Project":"P6","EtC":"30","Strategy":"5","Complexity":"8","Production":"3","Compliance":"3","PM":"MGA","Status":"Green"},{"Project":"P7","EtC":"15","Strategy":"6","Complexity":"7","Production":"4","Compliance":"4","PM":"MGA","Status":"Green"},{"Project":"P8","EtC":"35","Strategy":"8","Complexity":"3","Production":"5","Compliance":"5","PM":"MGA","Status":"Red"}];
    	var labels={
    	            "kpi1":$scope.company.projkpi1lable,
    	            "kpi2":$scope.company.projkpi2lable,
    	            "kpi3":$scope.company.projkpi3lable,
                    "total":"Prio total",
                    "EtC":"Estimate to Complete",
                    "ab":"Approved budget",
    	           "fte":"FTE"
    	};
    	if(data.length>0 && $scope.xaxis && $scope.yaxis && $scope.size){
    		var scatter = new Scatter('#scatter', data, labels, $scope.xaxis, $scope.yaxis, $scope.size, $scope);
    	}
	}

	$scope.drawRiskScatter = function() {
		console.log('DRAW RISK SCATTER: ' + $scope.riskxaxis);
		//console.log($scope.allrisks);
		var data=[];
    	angular.forEach($scope.allrisks, function(p) {
    		//console.log(p);
    		//console.log(p.freq.kpi1);
            var laststatus="black";
    		var proj={}
    		try{
	    		var proj={
                    "poid": p.projectoid,
	    	        "projectstate": p.projectstate,
	    	        "riskstate": p.state,
	    	        "Project": 'Project: ' + p.projecttitle + '<br/>BU: ' + p.buname +'<br/>Risk: '+ p.title,
	    	        "total": p.total,
	    	        "EtC": p.EtC,
	    	        "ab": p.ab,
	    	        "fte": p.fte,
                    "kpi1": p.freq.kpi1,
	    	        "kpi2": p.freq.kpi2,
	    	        "kpi3": p.freq.kpi3,
                    "ptotal": p.ptotal,
                    "wtotal": p.wtotal,
                    "pkpi1": p.pkpi1,
	    	        "pkpi2": p.pkpi2,
	    	        "pkpi3": p.pkpi3,
                    "Status": p.status,
                    "Laststatus": laststatus
	    	    };
    		}catch(e){
	    		var proj={
                    "poid": p.projectoid,
	    	        "projectstate": "Closed",
	    	        "riskstate": "Closed",
	    	        "Project": p.title,
                    "total": 10,
	    	        "wtotal": 10,
                    "EtC": 10,
	    	        "ab": 10,
	    	        "fte": 1,
	    	        "Strategy": p.freq.kpi1,
	    	        "Complexity": p.freq.kpi2,
	    	        "Production": p.freq.kpi3,
	    	        "PM": p.pm,
	    	        "Status": 'Green',
	    	        "Laststatus": 'Green'
	    	    };
    		}
    		if(proj.projectstate!="Closed" && proj.projectstate!="Onhold" && proj.riskstate!="Closed"){
    		  data.push(proj)
            }
    	});
		
    	var labels={
    	            "kpi1":$scope.company.riskkpi1lable,
    	            "kpi2":$scope.company.riskkpi2lable,
    	            "kpi3":$scope.company.riskkpi3lable,
                    "total": "Risk points total",
	    	        "EtC": "Project EtC",
	    	        "ab": "Project App. Budget",
	    	        "fte": "Project FTE",
                    "ptotal": "Project points total",
                    "wtotal": "Project/Risk points total",
                    "pkpi1": "Project " + $scope.company.projkpi1lable,
	    	        "pkpi2": "Project " + $scope.company.projkpi2lable,
	    	        "pkpi3": "Project " + $scope.company.projkpi3lable,
    	};
    	if(data.length>0 && $scope.xaxis && $scope.yaxis && $scope.size){
    		var scatter = new Scatter('#riskscatter', data, labels, $scope.riskxaxis, $scope.riskyaxis, $scope.risksize);
    	}
	}

	
	saveProjectRedirect = function(redirect) {
		$scope.projecthaschanged=false;	//reset save button colour
		if($scope.project._id){	//update
			restService.updateData('project',angular.fromJson($scope.project)).success(function(dataResponse) {
				stateService.setProject(dataResponse);//$scope.project=dataResponse;
				//stateService.loadCompany();
				if(redirect){
					$location.path(redirect);
				}
			}).error(function(dataResponse) {console.log('ERROR ...');});
		}else{	//add
			$scope.project.freq={};
			$scope.project.freq.kpi1=$scope.projects.length;
			$scope.project.freq.kpi2=$scope.projects.length;
			$scope.project.freq.kpi3=$scope.projects.length;
			restService.saveData('project',angular.fromJson($scope.project)).success(function(dataResponse) {
				stateService.setProject(dataResponse);
				$scope.project=dataResponse;	//update the oid via angular
				stateService.addProject(dataResponse);
				if(redirect){
					$location.path(redirect);
				}
			}).error(function(dataResponse) {console.log('ERROR ...');});
		}
	}

}]);
